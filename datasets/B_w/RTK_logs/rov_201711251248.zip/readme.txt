Log start time: 2017-11-25 12:48:53
Log stop time:  2017-11-25 12:51:27
Navigation messages parsed:
Messages inside: Errors: 1, GPS nav: 20, SBAS log: 308, Obs: 760