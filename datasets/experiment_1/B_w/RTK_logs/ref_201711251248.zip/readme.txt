Log start time: 2017-11-25 12:48:53
Log stop time:  2017-11-25 12:51:26
Navigation messages parsed:
Messages inside: GPS nav: 26, Obs: 154