Log start time: 2017-11-25 12:57:14
Log stop time:  2017-11-25 12:59:35
Navigation messages parsed:
Messages inside: Errors: 4, GPS nav: 19, SBAS log: 283, Obs: 646