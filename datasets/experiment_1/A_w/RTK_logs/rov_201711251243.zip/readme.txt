Log start time: 2017-11-25 12:43:09
Log stop time:  2017-11-25 12:45:39
Navigation messages parsed:
Messages inside: GPS nav: 21, SBAS log: 302, Obs: 699