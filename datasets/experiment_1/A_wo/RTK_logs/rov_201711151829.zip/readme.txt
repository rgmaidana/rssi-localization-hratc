Log start time: 2017-11-15 18:29:27
Log stop time:  2017-11-15 18:32:08
Navigation messages parsed:
Messages inside: GPS nav: 22, SBAS log: 161, Obs: 804