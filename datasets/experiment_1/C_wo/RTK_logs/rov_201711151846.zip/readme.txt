Log start time: 2017-11-15 18:46:40
Log stop time:  2017-11-15 18:49:06
Navigation messages parsed:
Messages inside: GPS nav: 17, SBAS log: 294, Obs: 728