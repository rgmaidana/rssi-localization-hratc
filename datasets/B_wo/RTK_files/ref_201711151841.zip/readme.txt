Log start time: 2017-11-15 18:41:46
Log stop time:  2017-11-15 18:44:19
Navigation messages parsed:
Messages inside: GPS nav: 21, Obs: 154