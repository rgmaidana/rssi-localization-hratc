Log start time: 2017-11-15 18:41:41
Log stop time:  2017-11-15 18:44:20
Navigation messages parsed:
Messages inside: GPS nav: 14, SBAS log: 159, Obs: 794